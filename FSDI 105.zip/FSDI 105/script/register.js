console.log("User register");
//create constructor
class User{
    constructor(email,pass,first,last,age,address,phone,payment,color){
        this.email=email;
        this.password=pass;
        this.fname=first;
        this.lname=last;
        this.age=age;
        this.address=address;
        this.phone=phone;
        this.payment=payment;
        this.color=color;
    }
}

function registerUser(){
    let email = $("#userEmail").val();//****check your id on the HTML */
    let password = $("#userPassword").val();
    let first = $("#firstName").val();
    let last = $("#lastName").val();
    let age = $("#userAge").val();
    let address = $("#userAddress").val();
    let phone = $("#userPhone").val();
    let payment = $("#userPayment").val();
    let color = $("#userColor").val();

    let user=new User(email,password,first,last,age,address,phone,payment,color);
    console.log(user);
}
function init(){
    console.log("Init function");

}
window.onload=init();